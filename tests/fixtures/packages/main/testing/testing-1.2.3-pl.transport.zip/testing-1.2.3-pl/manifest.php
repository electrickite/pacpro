<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' =>
  array (
  ),
  'manifest-vehicles' =>
  array (
    0 =>
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '60c115a001081fee9008c075ba7765be',
      'native_key' => 'testing',
      'filename' => 'modNamespace/926c28f5d51d4e7ec92db952bde8a0c6.vehicle',
      'namespace' => 'testing',
    ),
    1 =>
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => 'efbe2ee1fbb8974daa8e0921b166cf71',
      'native_key' => NULL,
      'filename' => 'modCategory/a99d14bcd926fe2c8b308b5eccaf7c30.vehicle',
      'namespace' => 'testing',
    ),
  ),
);
